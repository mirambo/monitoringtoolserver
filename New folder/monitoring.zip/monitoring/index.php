<?php require_once("include/connection.php"); ?> 

<!DOCTYPE html>
<html lang="en">
<head>
  <title>E3EMPOWER AFRICA</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/4.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js"></script>
</head>


<body>

<div class="container"> 
	<div class="row">
			<div class="col-sm-12">
					<center><img src="image/e3alog.png" ></center>
					
				<center>
					<div class="alert alert-success" role="alert">
					MONITORING TOOL DASHBOARD
					</div>
				</center>
					
					<a href="ci_group.php"> <center><button type="submit" class="btn btn-danger"><b>COMPASSION</b></button> </center></a><br>
					<a href="other_group.php"> <center><button type="submit" class="btn btn-danger"><b>TRAINING CENTER</b></button> </center></a><br>
					
					
				   
			</div>
	</div>
</div>

</body>
</html>